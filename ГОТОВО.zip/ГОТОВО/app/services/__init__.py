"""Shared application services."""
